package com.webthuexe.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@WebServlet("/booking-confirm")
public class BookingServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Lấy dữ liệu từ Detail gửi qua
        String idXe = request.getParameter("id_xe");
        String tenXe = request.getParameter("ten_xe");
        String giaStr = request.getParameter("gia_thue");
        String nThue = request.getParameter("ngay_thue");
        String nTra = request.getParameter("ngay_tra");

        // Kiểm tra dữ liệu đầu vào
        if (idXe == null || nThue == null || nTra == null || giaStr == null) {
            response.sendRedirect(request.getContextPath() + "/XeMay");
            return;
        }

        try {
            // 2. Tính toán số ngày và tiền
            double gia = Double.parseDouble(giaStr);
            LocalDate d1 = LocalDate.parse(nThue);
            LocalDate d2 = LocalDate.parse(nTra);
            long soNgay = ChronoUnit.DAYS.between(d1, d2);
            
            // Nếu nhận và trả cùng ngày tính 1 ngày
            if (soNgay <= 0) soNgay = 1; 
            double tongTien = soNgay * gia;

            // 3. Đưa dữ liệu vào request attribute
            request.setAttribute("idXe", idXe);
            request.setAttribute("tenXe", tenXe);
            request.setAttribute("nThue", nThue);
            request.setAttribute("nTra", nTra);
            request.setAttribute("soNgay", soNgay);
            request.setAttribute("tongTien", tongTien);

            // 4. Chuyển sang trang JSP để hiển thị
            request.getRequestDispatcher("/user/booking_confirm.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/user/detail.jsp?id=" + idXe);
        }
    }
}