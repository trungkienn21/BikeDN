package com.webthuexe.controller.admin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Base64;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.webthuexe.db.DBContext;

@WebServlet("/admin/car-manager")
public class CarManagementServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // doGet: Xử lý Xóa xe
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        checkAdmin(request, response);
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            String id = request.getParameter("id");
            try (Connection conn = DBContext.getConnection()) {
                String sql = "DELETE FROM xe_may WHERE id=?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, id);
                pst.executeUpdate();
                response.sendRedirect("quanly_xe.jsp?msg=success");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("quanly_xe.jsp?msg=error");
            }
        }
    }

    // doPost: Xử lý Thêm mới & Cập nhật
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        checkAdmin(request, response);
        request.setCharacterEncoding("UTF-8");

        String id = request.getParameter("id");
        String maXe = request.getParameter("ma_xe");
        String tenXe = request.getParameter("ten_xe");
        String loaiXe = request.getParameter("loai_xe");
        String giaThue = request.getParameter("gia_thue");
        String hinh = request.getParameter("hinh_anh");
        String base64Img = request.getParameter("base64_img");
        String trangThai = request.getParameter("trang_thai");

        // Xử lý ảnh Base64
        if (base64Img != null && !base64Img.isEmpty() && hinh != null && !hinh.isEmpty()) {
            try {
                byte[] imageBytes = Base64.getDecoder().decode(base64Img);
                String appPath = request.getServletContext().getRealPath("");
                String savePath = appPath + File.separator + "images";
                File fileDir = new File(savePath);
                if (!fileDir.exists())
                    fileDir.mkdirs();

                File file = new File(savePath + File.separator + hinh);
                try (FileOutputStream fos = new FileOutputStream(file)) {
                    fos.write(imageBytes);
                }
            } catch (Exception e) {
                e.printStackTrace(); // Ignore image error to allow db save
            }
        }

        try (Connection conn = DBContext.getConnection()) {
            if (id == null || id.isEmpty()) {
                // INSERT
                String sql = "INSERT INTO xe_may (ma_xe, ten_xe, loai_xe, gia_thue, hinh_anh, trang_thai) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, maXe);
                pst.setString(2, tenXe);
                pst.setString(3, loaiXe);
                pst.setString(4, giaThue);
                pst.setString(5, hinh);
                pst.setString(6, trangThai);
                pst.executeUpdate();
            } else {
                // UPDATE
                String sql = "UPDATE xe_may SET ma_xe=?, ten_xe=?, loai_xe=?, gia_thue=?, hinh_anh=?, trang_thai=? WHERE id=?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, maXe);
                pst.setString(2, tenXe);
                pst.setString(3, loaiXe);
                pst.setString(4, giaThue);
                pst.setString(5, hinh);
                pst.setString(6, trangThai);
                pst.setString(7, id);
                pst.executeUpdate();
            }
            response.sendRedirect("quanly_xe.jsp?msg=success");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("form_xe.jsp?msg=error");
        }
    }

    private void checkAdmin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("isAdmin") == null) {
            response.sendRedirect("../auth/login.jsp");
        }
    }
}
