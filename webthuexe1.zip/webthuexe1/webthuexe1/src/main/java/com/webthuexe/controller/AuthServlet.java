package com.webthuexe.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.webthuexe.db.DBContext;

@WebServlet("/auth")
public class AuthServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // doGet: Xử lý Đăng xuất
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("logout".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate(); 
            }
        }
        // ĐÚNG: Chuyển về Servlet XeMay để load lại danh sách xe cho trang chủ
        response.sendRedirect(request.getContextPath() + "/XeMay");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if ("login".equals(action)) {
            handleLogin(request, response);
        } else if ("register".equals(action)) {
            handleRegister(request, response);
        }
    }

    private void handleLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String u = request.getParameter("ten_dang_nhap");
        String p = request.getParameter("matkhau");

        try (Connection conn = DBContext.getConnection()) {
            String sql = "SELECT * FROM nguoi_dung WHERE ten_dang_nhap=? AND mat_khau=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, u);
            pst.setString(2, p);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("userFullName", rs.getString("ho_ten"));
                session.setAttribute("userId", rs.getInt("id"));

                int role = rs.getInt("vai_tro");
                if (role == 1) {
                    session.setAttribute("isAdmin", true);
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard.jsp");
                } else {
                    // ĐÚNG: Quay về Servlet danh sách xe thay vì file JSP trống
                    response.sendRedirect(request.getContextPath() + "/XeMay");
                }
            } else {
                response.sendRedirect("auth/login.jsp?msg=error");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("auth/login.jsp?msg=system_error");
        }
    }

    private void handleRegister(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String u = request.getParameter("user");
        String p = request.getParameter("pass");
        String f = request.getParameter("fullname");
        String e = request.getParameter("email");

        try (Connection conn = DBContext.getConnection()) {
            PreparedStatement checkSt = conn.prepareStatement("SELECT id FROM nguoi_dung WHERE ten_dang_nhap = ?");
            checkSt.setString(1, u);
            if (checkSt.executeQuery().next()) {
                response.sendRedirect("auth/register.jsp?msg=exists");
                return;
            }

            String sql = "INSERT INTO nguoi_dung (ten_dang_nhap, mat_khau, ho_ten, email, vai_tro) VALUES (?, ?, ?, ?, 0)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, u);
            pst.setString(2, p);
            pst.setString(3, f);
            pst.setString(4, e);
            pst.executeUpdate();

            // Đăng ký xong có thể cho đăng nhập luôn hoặc về trang login
            response.sendRedirect("auth/login.jsp?msg=register_success");

        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("auth/register.jsp?msg=system_error");
        }
    }
}