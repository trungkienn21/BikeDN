package com.webthuexe.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/process-booking")
public class ProcessBookingServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Integer uId = (Integer) session.getAttribute("userId");
        // Lấy họ tên từ session để tránh lỗi "Field 'ho_ten' doesn't have a default value"
        String hoTen = (String) session.getAttribute("hoTen"); 

        if (uId == null) {
            response.sendRedirect(request.getContextPath() + "/auth/login.jsp");
            return;
        }

        // Lấy dữ liệu từ form gửi qua
        String idXe = request.getParameter("id_xe");
        String ngayThue = request.getParameter("ngay_thue");
        String ngayTra = request.getParameter("ngay_tra");
        String tongTien = request.getParameter("tong_tien");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/webthuexe", "root", "");

            // 1. Lưu vào bảng don_thue_xe (Thêm cột ho_ten vào câu lệnh INSERT)
            String sql = "INSERT INTO don_thue_xe (id_nguoi_dung, ho_ten, id_xe, ngay_thue, ngay_tra, tong_tien, trang_thai_don) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, uId);
            pst.setString(2, (hoTen != null) ? hoTen : "Khách hàng"); // Sửa lỗi thiếu giá trị cho ho_ten
            pst.setString(3, idXe);
            pst.setString(4, ngayThue);
            pst.setString(5, ngayTra);
            pst.setDouble(6, Double.parseDouble(tongTien));
            pst.setString(7, "Chờ duyệt"); // Để hiện nút "Hủy đơn" bên GUI History
            pst.executeUpdate();
            
            // 2. Cập nhật trạng thái xe thành 'Đã thuê' (1)
            String sqlUpdate = "UPDATE xe_may SET trang_thai = 1 WHERE id = ?";
            PreparedStatement pstUpdate = conn.prepareStatement(sqlUpdate);
            pstUpdate.setString(1, idXe);
            pstUpdate.executeUpdate();

            conn.close();

            // 3. Chuyển hướng về GUI History
            response.sendRedirect(request.getContextPath() + "/lich-su-thue");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Lỗi xử lý: " + e.getMessage());
        }
    }
}