package com.webthuexe.controller.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.webthuexe.db.DBContext;

@WebServlet("/admin/order-manager")
public class OrderManagementServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("isAdmin") == null) {
            response.sendRedirect("../auth/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        String idDon = request.getParameter("id");
        String idXe = request.getParameter("id_xe");

        if (idDon == null || action == null) {
            response.sendRedirect("quanly_don.jsp");
            return;
        }

        try (Connection conn = DBContext.getConnection()) {
            if ("return".equals(action) || "complete".equals(action)) {
                // Return/Complete
                updateOrderStatus(conn, idDon, "Hoàn tất");
                if (idXe != null)
                    updateCarStatus(conn, idXe, 0); // Sẵn sàng

            } else if ("approve".equals(action)) {
                // Approve
                updateOrderStatus(conn, idDon, "Thành công");
                // Car stays status 1 (Rented)

            } else if ("cancel".equals(action)) {
                // Cancel
                updateOrderStatus(conn, idDon, "Đã hủy");
                if (idXe != null)
                    updateCarStatus(conn, idXe, 0); // Sẵn sàng
            }

            response.sendRedirect("quanly_don.jsp?msg=success");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("quanly_don.jsp?msg=error");
        }
    }

    private void updateOrderStatus(Connection conn, String idDon, String status) throws Exception {
        String sql = "UPDATE don_thue_xe SET trang_thai_don = ? WHERE id = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, status);
            pst.setString(2, idDon);
            pst.executeUpdate();
        }
    }

    private void updateCarStatus(Connection conn, String idXe, int status) throws Exception {
        String sql = "UPDATE xe_may SET trang_thai = ? WHERE id = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, status);
            pst.setString(2, idXe);
            pst.executeUpdate();
        }
    }
}
