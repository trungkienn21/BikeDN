package com.webthuexe.model;

public class XeMay {
    private int id;
    private String tenXe;
    private String loaiXe;
    private double giaThue;
    private int trangThai;
    private String hinhAnh;

    // Constructor bắt buộc phải có để XeMayDAO không bị lỗi dòng 16
    public XeMay(int id, String tenXe, String loaiXe, double giaThue, int trangThai, String hinhAnh) {
        this.id = id;
        this.tenXe = tenXe;
        this.loaiXe = loaiXe;
        this.giaThue = giaThue;
        this.trangThai = trangThai;
        this.hinhAnh = hinhAnh;
    }

    // Tạo các Getter (Quan trọng để file detail.jsp gọi được dữ liệu)
    public int getId() { return id; }
    public String getTenXe() { return tenXe; }
    public String getLoaiXe() { return loaiXe; }
    public double getGiaThue() { return giaThue; }
    public int getTrangThai() { return trangThai; }
    public String getHinhAnh() { return hinhAnh; }
}