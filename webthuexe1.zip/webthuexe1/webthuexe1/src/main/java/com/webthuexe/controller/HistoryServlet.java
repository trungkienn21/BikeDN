package com.webthuexe.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/lich-su-thue")
public class HistoryServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Integer uId = (Integer) session.getAttribute("userId");

        if (uId == null) {
            response.sendRedirect(request.getContextPath() + "/auth/login.jsp");
            return;
        }

        List<Map<String, Object>> listDonHang = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/webthuexe", "root", "");
            
            // Câu lệnh SQL lấy dữ liệu cho GUI History
            String sql = "SELECT d.id, x.ten_xe, d.ngay_thue, d.ngay_tra, d.tong_tien, d.trang_thai_don " +
                         "FROM don_thue_xe d JOIN xe_may x ON d.id_xe = x.id " +
                         "WHERE d.id_nguoi_dung = ? ORDER BY d.id DESC";
            
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, uId);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("id", rs.getInt("id"));
                map.put("tenXe", rs.getString("ten_xe"));
                map.put("ngayThue", rs.getString("ngay_thue"));
                map.put("ngayTra", rs.getString("ngay_tra"));
                map.put("tongTien", rs.getDouble("tong_tien"));
                map.put("trangThai", rs.getString("trang_thai_don"));
                listDonHang.add(map);
            }
            conn.close();
            request.setAttribute("historyList", listDonHang); // Đẩy dữ liệu sang JSP
            
        } catch (Exception e) { e.printStackTrace(); }
        
        request.getRequestDispatcher("/user/history.jsp").forward(request, response);
    }
}