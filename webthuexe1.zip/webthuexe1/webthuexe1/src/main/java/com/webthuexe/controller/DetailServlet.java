package com.webthuexe.controller;

import com.webthuexeDAO.XeMayDAO;
import com.webthuexe.model.XeMay;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/xe-chi-tiet") // Địa chỉ để truy cập trang
public class DetailServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Lấy ID xe từ URL (ví dụ: xe-chi-tiet?id=5)
        String idParam = request.getParameter("id");
        
        if (idParam != null && !idParam.isEmpty()) {
            try {
                int id = Integer.parseInt(idParam);
                
                // 2. Gọi DAO lấy dữ liệu xe
                XeMayDAO dao = new XeMayDAO();
                XeMay xe = dao.getXeById(id);
                
                // 3. Đẩy dữ liệu vào Request để JSP hiển thị
                request.setAttribute("xe", xe);
                
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        
        // 4. Chuyển hướng sang file JSP (vị trí file trong webapp/user/detail.jsp)
        request.getRequestDispatcher("/user/detail.jsp").forward(request, response);
    }
}