package com.webthuexe.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

import com.webthuexeDAO.thuexeDAO;

import entity.XeMay;

@WebServlet("/XeMay")
public class XeMayServlet extends HttpServlet {

    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	
	        thuexeDAO dao = new thuexeDAO(); 
	        List<XeMay> listXe = dao.getAllXeMay(); 
	        request.setAttribute("listXe", listXe);
	        request.setAttribute("hasData", listXe != null && !listXe.isEmpty());
	
	        request.getRequestDispatcher("/WEB-INF/views/danh_sach.jsp")
	               .forward(request, response);
    }
 }

