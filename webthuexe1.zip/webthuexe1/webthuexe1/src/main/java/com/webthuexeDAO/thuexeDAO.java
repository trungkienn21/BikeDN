package com.webthuexeDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import connect.DBContext;
import entity.XeMay;

public class thuexeDAO {

    public List<XeMay> getAllXeMay() {
        List<XeMay> list = new ArrayList<>();
        String sql = "SELECT * FROM xe_may";

        try (Connection conn = DBContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                XeMay xe = new XeMay();
                xe.setId(rs.getInt("id"));
                xe.setTenXe(rs.getString("ten_xe"));

                String loai = rs.getString("loai_xe");
                xe.setLoaiXe(loai == null ? "Xe máy" : loai);

                xe.setGiaThue(rs.getDouble("gia_thue"));

                String hinh = rs.getString("hinh_anh");
                xe.setHinhAnh((hinh == null || hinh.isEmpty()) ? "default.png" : hinh);

                xe.setTrangThai(rs.getInt("trang_thai"));

                list.add(xe);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
