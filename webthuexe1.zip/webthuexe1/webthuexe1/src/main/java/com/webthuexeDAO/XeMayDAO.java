package com.webthuexeDAO; // 1. Sửa lại package cho đúng

import java.sql.*;
import com.webthuexe.db.DBContext;
import com.webthuexe.model.XeMay;

public class XeMayDAO {
    public XeMay getXeById(int id) {
        String sql = "SELECT * FROM xe_may WHERE id = ?";
        try (Connection conn = DBContext.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) { // Nên dùng try-with-resources cho ResultSet
                if (rs.next()) {
                	// Trong file XeMayDAO.java, đoạn return phải sửa lại thế này:
                	return new XeMay(
                	    rs.getInt("id"),
                	    rs.getString("ten_xe"),   // Database là ten_xe
                	    rs.getString("loai_xe"),  // Database là loai_xe
                	    rs.getDouble("gia_thue"),
                	    rs.getInt("trang_thai"),
                	    rs.getString("hinh_anh")
                	);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}