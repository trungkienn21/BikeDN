package connect;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBContext {

    public static Connection getConnection() throws Exception {

        String user = "root";
        String pass = ""; // Laragon: để trống

        // ✅ URL JDBC ĐÚNG
        String url = "jdbc:mysql://localhost:3306/webthuexe"
                   + "?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC";

        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url, user, pass);
    }

   
    }

