package entity;

public class XeMay {
    private int id;
    private String tenXe;
    private String loaiXe;
    private double giaThue;
    private String hinhAnh;
    private int trangThai;

    public XeMay() {}

    public XeMay(int id, String tenXe, String loaiXe, double giaThue, String hinhAnh, int trangThai) {
        this.id = id;
        this.tenXe = tenXe;
        this.loaiXe = loaiXe;
        this.giaThue = giaThue;
        this.hinhAnh = hinhAnh;
        this.trangThai = trangThai;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTenXe() { return tenXe; }
    public void setTenXe(String tenXe) { this.tenXe = tenXe; }

    public String getLoaiXe() { return loaiXe; }
    public void setLoaiXe(String loaiXe) { this.loaiXe = loaiXe; }

    public double getGiaThue() { return giaThue; }
    public void setGiaThue(double giaThue) { this.giaThue = giaThue; }

    public String getHinhAnh() { return hinhAnh; }
    public void setHinhAnh(String hinhAnh) { this.hinhAnh = hinhAnh; }

    public int getTrangThai() { return trangThai; }
    public void setTrangThai(int trangThai) { this.trangThai = trangThai; }

    @Override
    public String toString() {
        return "XeMay [id=" + id + ", tenXe=" + tenXe + ", loaiXe=" + loaiXe +
               ", giaThue=" + giaThue + ", hinhAnh=" + hinhAnh +
               ", trangThai=" + trangThai + "]";
    }

    
    }

