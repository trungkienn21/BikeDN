<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Xác nhận thuê xe | THUEXEDANANG</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .confirm-card { border-radius: 20px; border: none; overflow: hidden; max-width: 450px; margin: 50px auto; }
        .header-gradient { background: linear-gradient(135deg, #27ae60, #2ecc71); color: white; padding: 30px; }
        .info-group { border-bottom: 1px solid #f1f1f1; padding: 15px 0; }
        .label { font-size: 0.75rem; text-transform: uppercase; color: #95a5a6; font-weight: 700; }
        .value { color: #2c3e50; font-weight: 700; font-size: 1.1rem; }
        .price-highlight { background: #f8fff9; border: 2px dashed #2ecc71; border-radius: 15px; padding: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="confirm-card shadow-lg bg-white">
            <div class="header-gradient text-center">
                <i class="bi bi-check2-circle display-4"></i>
                <h4 class="fw-bold mt-2">XÁC NHẬN ĐƠN HÀNG</h4>
            </div>

            <div class="card-body p-4">
                <div class="info-group">
                    <div class="label">Tên xe</div>
                    <div class="value text-success">${tenXe}</div>
                </div>

                <div class="row info-group">
                    <div class="col-6">
                        <div class="label">Nhận xe</div>
                        <div class="value">${nThue}</div>
                    </div>
                    <div class="col-6 border-start text-end">
                        <div class="label">Trả xe</div>
                        <div class="value">${nTra}</div>
                    </div>
                </div>

                <div class="price-highlight text-center my-4">
                    <div class="label mb-1">Thời gian: ${soNgay} ngày</div>
                    <div class="h2 fw-bold text-success mb-0">
                        <fmt:formatNumber value="${tongTien}" pattern="#,###"/> đ
                    </div>
                </div>

                <form action="${pageContext.request.contextPath}/process-booking" method="POST">
                    <input type="hidden" name="id_xe" value="${idXe}">
                    <input type="hidden" name="ngay_thue" value="${nThue}">
                    <input type="hidden" name="ngay_tra" value="${nTra}">
                    <input type="hidden" name="tong_tien" value="${tongTien}">

                    <button type="submit" class="btn btn-success w-100 py-3 rounded-3 fw-bold shadow">
                        XÁC NHẬN & THANH TOÁN
                    </button>
                    
                    <button type="button" onclick="history.back()" class="btn btn-link w-100 text-decoration-none text-muted mt-2 small">
                        Thay đổi thông tin
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>