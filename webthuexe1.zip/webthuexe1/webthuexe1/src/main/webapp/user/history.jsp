<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lịch sử thuê xe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-light">
    <jsp:include page="/includes/client_navbar.jsp" />

    <div class="container py-5">
        <div class="card shadow border-0 rounded-4 p-4">
            <h2 class="mb-4 fw-bold text-success border-start border-4 ps-3">LỊCH SỬ THUÊ XE</h2>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Mã Đơn</th>
                            <th>Tên Xe</th>
                            <th>Thời gian</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:choose>
                            <c:when test="${not empty historyList}">
                                <c:forEach items="${historyList}" var="dh">
                                    <tr>
                                        <td class="fw-bold">#${dh.id}</td>
                                        <td>${dh.tenXe}</td>
                                        <td>${dh.ngayThue} đến ${dh.ngayTra}</td>
                                        <td class="fw-bold text-danger">
                                            <fmt:formatNumber value="${dh.tongTien}" pattern="#,###" />đ
                                        </td>
                                        <td>
                                            <c:set var="badge" value="secondary" />
                                            <c:if test="${dh.trangThai == 'Chờ duyệt'}"><c:set var="badge" value="warning text-dark" /></c:if>
                                            <c:if test="${dh.trangThai == 'Thành công' || dh.trangThai == 'Hoàn tất'}"><c:set var="badge" value="success" /></c:if>
                                            <c:if test="${dh.trangThai == 'Đã hủy'}"><c:set var="badge" value="danger" /></c:if>
                                            
                                            <span class="badge rounded-pill px-3 py-2 bg-${badge}">${dh.trangThai}</span>
                                        </td>
                                        <td>
                                            <c:if test="${dh.trangThai == 'Chờ duyệt'}">
                                                <button onclick="confirmDelete(${dh.id})" class="btn btn-sm btn-outline-danger rounded-3">Hủy đơn</button>
                                            </c:if>
                                            <c:if test="${dh.trangThai != 'Chờ duyệt'}">
                                                <span class="text-muted small">--</span>
                                            </c:if>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </c:when>
                            <c:otherwise>
                                <tr><td colspan="6" class="text-center py-5 text-muted">Bạn chưa có lịch sử thuê xe nào.</td></tr>
                            </c:otherwise>
                        </c:choose>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-4">
                <a href="${pageContext.request.contextPath}/XeMay" class="btn btn-secondary rounded-pill px-4">
                    <i class="bi bi-arrow-left me-2"></i> Quay lại trang chủ
                </a>
            </div>
        </div>
    </div>

    <jsp:include page="/includes/client_footer.jsp" />

    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Xác nhận xóa?',
                text: "Bạn sẽ không thể hoàn tác hành động này!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Xóa ngay',
                cancelButtonText: 'Hủy'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '${pageContext.request.contextPath}/booking?action=cancel&id=' + id;
                }
            });
        }
    </script>
</body>
</html>