<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${xe.tenXe} | THUEXEDANANG</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root { --main-color: #2ecc71; --dark-blue: #2c3e50; }
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        
        /* Card chính */
        .glass-card { 
            background: white; 
            border-radius: 24px; 
            border: none; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.05); 
            overflow: hidden; 
        }
        
        /* Phần hình ảnh */
        .product-image-bg { 
            background: #fdfdfd; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            padding: 50px; 
        }
        .bike-img { 
            max-height: 420px; 
            filter: drop-shadow(0 15px 25px rgba(0,0,0,0.1)); 
            transition: transform 0.4s ease; 
        }
        .bike-img:hover { transform: scale(1.03); }

        /* Thông tin chi tiết */
        .details-panel { padding: 45px; background: white; }
        .type-badge { 
            background: rgba(46, 204, 113, 0.1); 
            color: var(--main-color); 
            font-weight: 700; 
            letter-spacing: 1px; 
            padding: 8px 16px; 
        }
        .price-tag { color: var(--dark-blue); font-size: 2.5rem; font-weight: 800; }
        
        /* Form đặt xe */
        .booking-section { 
            background: #f8f9fa; 
            border-radius: 20px; 
            padding: 25px; 
            border: 1px solid #eee; 
        }
        .form-control-custom { 
            border-radius: 12px; 
            padding: 12px; 
            border: 1px solid #ddd; 
            font-weight: 600; 
        }

        /* Tiện ích */
        .feature-box { font-size: 0.85rem; color: #7f8c8d; }
        .feature-box i { color: var(--main-color); margin-right: 8px; }

        /* Nút đặt xe */
        .btn-confirm { 
            background: var(--main-color); 
            border: none; 
            border-radius: 14px; 
            padding: 18px; 
            font-weight: 700; 
            transition: all 0.3s; 
        }
        .btn-confirm:hover { 
            background: #27ae60; 
            transform: translateY(-3px); 
            box-shadow: 0 10px 20px rgba(46, 204, 113, 0.3); 
        }

        .total-display-box { 
            background: white; 
            border: 2px dashed var(--main-color); 
            border-radius: 15px; 
            padding: 15px; 
        }
    </style>
</head>
<body>
    <%@ include file="../includes/client_navbar.jsp" %>

    <div class="container py-5">
        <a href="javascript:history.back()" class="btn btn-white bg-white rounded-pill px-4 mb-4 fw-bold shadow-sm border-0">
            <i class="bi bi-arrow-left me-2"></i> Trở về danh sách
        </a>

        <c:choose>
            <c:when test="${empty xe}">
                <div class="alert alert-danger rounded-4 border-0 p-5 text-center shadow">
                    <i class="bi bi-exclamation-triangle-fill display-4 d-block mb-3"></i>
                    <h4 class="fw-bold">Rất tiếc, xe này hiện không tồn tại!</h4>
                    <p class="mb-0">Dữ liệu có thể đã bị xóa hoặc đường dẫn không chính xác.</p>
                </div>
            </c:when>
            
            <c:otherwise>
                <div class="glass-card row g-0">
                    <div class="col-lg-7 product-image-bg">
                        <img src="${pageContext.request.contextPath}/images/${xe.hinhAnh}" 
                             class="bike-img img-fluid" alt="${xe.tenXe}">
                    </div>

                    <div class="col-lg-5 details-panel border-start">
                        <span class="badge type-badge rounded-pill mb-3 text-uppercase">${xe.loaiXe}</span>
                        <h1 class="fw-bold mb-2" style="color: var(--dark-blue);">${xe.tenXe}</h1>
                        
                        <div class="price-tag mb-4">
    <span id="unitPrice">
        <fmt:formatNumber value="${xe.giaThue}" pattern="#,###" />
    </span>
    <small class="fs-5 text-muted fw-normal"> đ/ngày</small>
</div>
                        <div class="row g-3 mb-4">
                            <div class="col-6 feature-box"><i class="bi bi-shield-check"></i> Bảo hiểm cơ bản</div>
                            <div class="col-6 feature-box"><i class="bi bi-headset"></i> Hỗ trợ sự cố 24/7</div>
                            <div class="col-6 feature-box"><i class="bi bi-plugin"></i> 02 Mũ bảo hiểm</div>
                            <div class="col-6 feature-box"><i class="bi bi-fuel-pump"></i> Xăng đầy bình</div>
                        </div>

                        <div class="booking-section">
                            <form action="${pageContext.request.contextPath}/booking-confirm" method="POST">
                                <input type="hidden" name="id_xe" value="${xe.id}">
                                <input type="hidden" name="ten_xe" value="${xe.tenXe}">
                                <input type="hidden" name="gia_thue" value="${xe.giaThue}">

                                <div class="row g-3 mb-4">
                                    <div class="col-6">
                                        <label class="form-label fw-bold small text-muted">NGÀY NHẬN</label>
                                        <input type="date" name="ngay_thue" id="ngay_thue" class="form-control form-control-custom" required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fw-bold small text-muted">NGÀY TRẢ</label>
                                        <input type="date" name="ngay_tra" id="ngay_tra" class="form-control form-control-custom" required>
                                    </div>
                                </div>

                                <div id="totalBox" class="total-display-box mb-4 text-center" style="display:none;">
                                    <span class="text-muted small fw-bold text-uppercase">Tạm tính:</span>
                                    <div class="fs-2 fw-bold text-success" id="totalDisplay">0 đ</div>
                                </div>

                                <c:choose>
                                    <c:when test="${xe.trangThai == 1}">
                                        <button type="button" class="btn btn-secondary w-100 py-3 rounded-4 fw-bold" disabled>
                                            <i class="bi bi-clock-history me-2"></i> XE ĐANG ĐƯỢC THUÊ
                                        </button>
                                    </c:when>
                                    <c:when test="${empty sessionScope.userId}">
                                        <a href="${pageContext.request.contextPath}/auth/login.jsp" class="btn btn-warning w-100 py-3 rounded-4 fw-bold text-dark">
                                            VUI LÒNG ĐĂNG NHẬP
                                        </a>
                                    </c:when>
                                    <c:otherwise>
                                        <button type="submit" class="btn btn-success btn-confirm w-100 text-white">
                                            TIẾP TỤC ĐẶT XE <i class="bi bi-arrow-right ms-2"></i>
                                        </button>
                                    </c:otherwise>
                                </c:choose>
                            </form>
                        </div>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
    </div> 
</body>
</html>