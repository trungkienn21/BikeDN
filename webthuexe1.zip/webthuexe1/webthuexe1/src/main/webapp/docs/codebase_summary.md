# Tổng Hợp Chức Năng Các File Trong Dự Án WebThueXe1

Tài liệu này liệt kê toàn bộ các file quan trọng trong dự án và giải thích chức năng của chúng.

## 1. Backend (Java Source) - `src/main/java`

Nơi xử lý logic nghiệp vụ, kết nối cơ sở dữ liệu và điều hướng trang web.

### Package `com.webthuexe.db`
*   **`DBContext.java`**:
    *   **Chức năng**: Quản lý kết nối tới MySQL Database (`webthuexe`).
    *   **Chi tiết**: Chứa thông tin đăng nhập DB (`url`, `user`, `pass`) và hàm `getConnection()` được dùng chung bởi cả dự án.

### Package `com.webthuexe.controller`
Chứa các Servlet xử lý logic cho người dùng thường (Khách).
*   **`AuthServlet.java`**:
    *   **Chức năng**: Xử lý Đăng Ký, Đăng Nhập và Đăng Xuất.
    *   **Logic**: Kiểm tra tài khoản/mật khẩu, phân quyền (Admin vs User), và tạo Session làm việc.
*   **`BookingServlet.java`**:
    *   **Chức năng**: Xử lý việc Đặt Xe của khách hàng.
    *   **Logic**: Nhận thông tin ngày thuê, tính tổng tiền, lưu đơn hàng vào DB và chuyển hướng người dùng đến trang xác nhận hoặc lịch sử.

### Package `com.webthuexe.controller.admin`
Chứa các Servlet dành riêng cho Quản Trị Viên (Admin).
*   **`CarManagementServlet.java`**:
    *   **Chức năng**: Quản lý danh sách xe máy (CRUD).
    *   **Logic**: Thêm xe mới (bao gồm upload ảnh), Sửa thông tin xe, Xóa xe, và Hiển thị danh sách xe trong trang Admin.
*   **`OrderManagementServlet.java`**:
    *   **Chức năng**: Quản lý đơn hàng thuê xe.
    *   **Logic**: Duyệt đơn hàng mới, Xác nhận khách trả xe (cập nhật trạng thái xe thành "Sẵn sàng"), và Hủy đơn hàng.

---

## 2. Frontend (Giao Diện) - `src/main/webapp`

Nơi chứa giao diện người dùng, sử dụng JSP (JavaServer Pages) kết hợp HTML/CSS/JS.

### Trang Chủ & Xác Thực
*   **`index.jsp`**:
    *   **Chức năng**: Trang chủ (Landing Page).
    *   **Nội dung**: Hiển thị danh sách tất cả xe đang có sẵn để khách chọn thuê.
*   **`auth/login.jsp`**: Form đăng nhập.
*   **`auth/register.jsp`**: Form đăng ký tài khoản mới.

### Phân Hệ User (Khách Hàng) - `webapp/user/`
*   **`detail.jsp`**:
    *   **Chức năng**: Xem chi tiết một chiếc xe.
    *   **Nội dung**: Hiển thị ảnh lớn, giá thuê, mô tả chi tiết và form chọn ngày để đặt xe.
*   **`booking_confirm.jsp`**:
    *   **Chức năng**: Trang xác nhận trước khi gửi đơn.
    *   **Nội dung**: Review lại thông tin xe, ngày thuê và tổng tiền dự kiến.
*   **`history.jsp`**:
    *   **Chức năng**: Lịch sử thuê xe.
    *   **Nội dung**: Danh sách các đơn hàng khách đã đặt và trạng thái hiện tại (Chờ duyệt, Đang thuê, Hoàn tất...).

### Phân Hệ Admin (Quản Trị) - `webapp/admin/`
*   **`dashboard.jsp`**:
    *   **Chức năng**: Bảng điều khiển trung tâm.
    *   **Nội dung**: Thống kê doanh thu, số lượng xe, số đơn hàng mới.
*   **`quanly_xe.jsp`**:
    *   **Chức năng**: Bảng danh sách xe.
    *   **Nội dung**: Hiển thị dạng bảng (Table), có các nút Thêm/Sửa/Xóa xe.
*   **`form_xe.jsp`**:
    *   **Chức năng**: Form nhập liệu cho xe.
    *   **Nội dung**: Dùng chung cho cả việc "Thêm mới" (Form trống) và "Chỉnh sửa" (Form điền sẵn thông tin cũ).
*   **`quanly_don.jsp`**:
    *   **Chức năng**: Bảng danh sách đơn hàng.
    *   **Nội dung**: Admin xem các đơn đặt thuê và thực hiện thao tác Duyệt/Trả xe/Hủy.

### Thành Phần Chung - `webapp/includes/`
*   Chứa các file như `navbar.jsp`, `footer.jsp`, `head.jsp` được nhúng vào các trang khác để đồng bộ giao diện và tránh lặp code.
