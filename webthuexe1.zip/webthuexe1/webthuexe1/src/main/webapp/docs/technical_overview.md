# Tài Liệu Kỹ Thuật Tổng Quan & Giải Thích Code

## 1. Mô Hình Kiến Trúc (MVC Model 2)
Dự án được xây dựng theo mô hình **MVC (Model - View - Controller)** tiêu chuẩn cho Java Web:

*   **VIEW (Giao diện):** Là các file `.jsp` trong thư mục `webapp/`. Nơi hiển thị dữ liệu và nhận thao tác từ người dùng (Click, Nhập liệu).
*   **CONTROLLER (Điều khiển):** Là các file `.java` (Servlet) trong `src/main/java/com/webthuexe/controller/`. "Bộ não" xử lý logic, kiểm tra dữ liệu và điều hướng.
*   **MODEL (Dữ liệu):** Là `DBContext` và Database MySQL. Nơi lưu trữ và truy xuất dữ liệu bền vững.

### Luồng Hoạt Động (Ví dụ: Đặt Xe)
1.  **View:** Khách nhập ngày thuê trên `booking_confirm.jsp` -> Bấm nút "Xác nhận" -> Gửi request `POST`.
2.  **Controller:** `BookingServlet` nhận request -> Kiểm tra đăng nhập -> Tính toán tiền -> Gọi Model.
3.  **Model:** Kết nối MySQL -> Chạy lệnh `INSERT` đơn hàng -> `UPDATE` trạng thái xe bận.
4.  **Kết thúc:** Controller chuyển hướng (Redirect) khách về trang `user/history.jsp` để xem kết quả.

---

## 2. Giải Thích Các Lệnh (Syntax) Quan Trọng

### A. Kết Nối Database (`DBContext.java`)
Đây là cổng giao tiếp giữa Java và MySQL.
*   `DriverManager.getConnection(...)`: Tạo một đường ống kết nối tới Database.
*   **Mục đích:** Bắt buộc phải có để lấy hoặc lưu dữ liệu.

### B. Servlet - Xử Lý Logic (`Files .java`)
Trong các Servlet luôn có 2 phương thức chính:
1.  **`doGet(...)`**:
    *   **Khi nào chạy:** Khi người dùng truy cập URL hoặc bấm vào link `<a>`.
    *   **Dùng để:** Lấy dữ liệu (như Xem danh sách, Hủy đơn, Xóa xe).
2.  **`doPost(...)`**:
    *   **Khi nào chạy:** Khi người dùng bấm nút `Submit` trong Form.
    *   **Dùng để:** Gửi dữ liệu lên để xử lý (như Đăng nhập, Đặt xe, Thêm xe mới).

#### Các Lệnh Cốt Lõi:
*   `request.getParameter("name")`:
    *   **Chức năng:** Hứng dữ liệu người dùng nhập từ ô input có `name="name"` bên phía JSP.
*   `session.getAttribute("userId")`:
    *   **Chức năng:** Kiểm tra xem ai đang dùng web. Nếu `null` nghĩa là chưa đăng nhập.
*   `response.sendRedirect("page.jsp")`:
    *   **Chức năng:** Chuyển người dùng sang trang khác sau khi xử lý xong (VD: Đăng nhập xong -> Chuyển về Trang chủ).

#### Xử Lý SQL (`PreparedStatement`):
Đây là cách Java chạy lệnh SQL an toàn (chống hack SQL Injection).
```java
// 1. Viết câu lệnh SQL có dấu ? làm chỗ trống
String sql = "SELECT * FROM xe_may WHERE id = ?"; 

// 2. Chuẩn bị xe chở lệnh
PreparedStatement pst = conn.prepareStatement(sql); 

// 3. Điền giá trị vào chỗ trống (số 1 là dấu ? thứ nhất)
pst.setInt(1, 10); 

// 4. Chạy lệnh và hứng kết quả (ResultSet dùng cho SELECT, int dùng cho UPDATE/INSERT)
ResultSet rs = pst.executeQuery(); 
```

### C. JSP - Hiển Thị (`Files .jsp`)
File HTML có nhúng code Java (`<% ... %>`).
*   `<%= bien %>`: In giá trị biến ra màn hình.
*   `<% if (dk) { ... } %>`: Ẩn/Hiện nội dung theo điều kiện (VD: Chỉ hiện nút "Xóa" nếu là Admin).
*   `rs.next()`: Dùng trong vòng lặp. Nghĩa là "Nếu còn dòng tiếp theo trong bảng dữ liệu thì làm tiếp".

---

## 3. Quy Tắc Chỉnh Sửa
*   **Sửa Giao diện (Màu, Chữ, Bố cục):** Sửa file `.jsp` hoặc `.css` trong `webapp/`.
*   **Sửa Logic (Tính tiền, Chặn quyền):** Sửa file `.java` (Servlet) trong `src/main/java/`.
*   **Thêm dữ liệu (Cột mới):** Sửa Database SQL trước -> Sửa Model -> Sửa Controller -> Sửa View.
