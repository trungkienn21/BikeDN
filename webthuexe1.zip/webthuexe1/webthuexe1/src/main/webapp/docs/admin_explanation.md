# Tài Liệu Hướng Dẫn Kỹ Thuật & Chức Năng - Admin (Quản Trị Viên)

## 1. Tổng Quan
Hệ thống dành cho Admin cung cấp các công cụ toàn diện để quản lý hoạt động kinh doanh cho thuê xe máy. Admin có quyền truy cập vào các trang thống kê, quản lý đội xe và xử lý đơn hàng của khách.

## 2. Cấu Trúc Code & Logic
Mọi xử lý của Admin nằm trong package `com.webthuexe.controller.admin` và thư mục `webapp/admin/`.

### 2.1. Đăng Nhập & Bảo Mật
*   **File xử lý:** `AuthServlet.java`
*   **Cơ chế:**
    *   Khi đăng nhập, hệ thống kiểm tra `vai_tro` từ database.
    *   Nếu `vai_tro == 1`, Session sẽ được set attributte `isAdmin = true`.
    *   **Bảo mật:** Tại đầu mỗi trang JSP của Admin (ví dụ `dashboard.jsp`), luôn có đoạn code kiểm tra:
        ```java
        if(session.getAttribute("isAdmin") == null) {
            response.sendRedirect("../auth/login.jsp");
            return;
        }
        ```
    *   Điều này ngăn chặn truy cập trái phép qua URL.

### 2.2. Dashboard (Tổng Quan)
*   **File hiển thị:** `admin/dashboard.jsp`
*   **Chức năng:** Hiển thị 4 chỉ số quan trọng theo thời gian thực:
    1.  **Tổng số xe:** Đếm toàn bộ xe trong bảng `xe_may`.
    2.  **Đang cho thuê:** Đếm xe có `trang_thai = 1`.
    3.  **Đơn thành công:** Đếm đơn có `trang_thai_don = 'Hoàn tất'`.
    4.  **Doanh thu thực:** Tổng `tong_tien` của các đơn đã hoàn tất.

### 2.3. Quản Lý Xe (Car Management)
*   **Servlet:** `CarManagementServlet.java` (URL: `/admin/car-manager`)
*   **Giao diện:**
    *   `admin/quanly_xe.jsp`: Danh sách xe (CRUD view).
    *   `admin/form_xe.jsp`: Form thêm mới/chỉnh sửa.
*   **Logic:**
    *   **Thêm xe:** Nhận thông tin (tên, biển số, giá, ảnh...) -> Insert vào DB. Ảnh được upload dạng Base64.
    *   **Sửa xe:** Load thông tin cũ -> Update DB.
    *   **Xóa xe:** Xóa record khỏi DB (Lưu ý: Chỉ xóa được xe chưa có đơn hàng liên quan).

### 2.4. Quản Lý Đơn Hàng (Order Management)
*   **Servlet:** `OrderManagementServlet.java` (URL: `/admin/order-manager`)
*   **Giao diện:** `admin/quanly_don.jsp`
*   **Quy trình xử lý đơn:**
    1.  **Chờ duyệt:** Đơn mới từ khách -> Admin bấm **Duyệt đơn** -> Trạng thái thành **Thành công**.
    2.  **Trả xe:** Khách trả xe -> Admin bấm **Hoàn tất** ->
        *   Cập nhật đơn thành `Hoàn tất`.
        *   Cập nhật xe về trạng thái `Sẵn sàng` (0).
    3.  **Hủy đơn:** Nếu khách bòm hàng hoặc hết xe -> Admin bấm **Hủy** ->
        *   Cập nhật đơn thành `Đã hủy`.
        *   Cập nhật xe về trạng thái `Sẵn sàng` (0).

## 3. Giải Thích Code Chi Tiết cho Admin

### A. Kiểm tra quyền Admin (Security)
Đoạn code luôn đặt đầu file JSP Admin:
```java
// Lấy cờ 'isAdmin' từ phiên làm việc
if(session.getAttribute("isAdmin") == null) {
    // Nếu không có (người lạ hoặc chỉ là user thường) -> Đẩy về trang Login
    response.sendRedirect("../auth/login.jsp"); 
    return; // Dừng xử lý ngay
}
```

### B. Thống kê Doanh thu (SQL - Dashboard)
Đoạn SQL phức tạp nhất trong `dashboard.jsp` để tính tiền:
```sql
SELECT 
    COUNT(*) as cnt, // Đếm tổng số đơn
    SUM(CASE WHEN trang_thai_don = 'Hoàn tất' THEN tong_tien ELSE 0 END) as total_rev 
    // Chỉ cộng tiền (tong_tien) nếu đơn đã 'Hoàn tất', còn lại cộng 0
FROM don_thue_xe 
WHERE trang_thai_don != 'Đã hủy' // Không tính đơn hủy
```

### C. Xử lý Ảnh (Image Upload - `CarManagementServlet`)
Cách biến ảnh upload thành file lưu trên server:
```java
Part filePart = request.getPart("hinh"); // Lấy file từ <input type="file" name="hinh">
String fileName = filePart.getSubmittedFileName(); // Lấy tên file gốc
// Lưu vào thư mục images trên server
filePart.write("path/to/webapp/images/" + fileName); 
```

### D. Duyệt Đơn (Transaction - `OrderManagementServlet`)
Sử dụng Transaction để đảm bảo tính nhất quán (Hoặc thành công cả 2, hoặc thất bại cả 2):
```java
conn.setAutoCommit(false); // 1. Tắt tự động lưu
try {
    // 2. Chuyển trạng thái Đơn -> 'Hoàn tất'
    updateOrderStatus(conn, idDon, "Hoàn tất");
    // 3. Chuyển trạng thái Xe -> 'Sẵn sàng' (0)
    updateCarStatus(conn, idXe, 0); 
    
    conn.commit(); // 4. Mọi thứ OK -> Lưu vào DB
} catch (Exception e) {
    conn.rollback(); // 5. Có lỗi -> Hủy hết các bước trên, quay về như cũ
}
```

## 4. Phân Tích Code: Xử Lý Duyệt & Hủy Đơn
Dưới đây là từng dòng code của hàm `doPost` trong `OrderManagementServlet`:

```java
// Bắt đầu hàm xử lý khi Admin bấm nút Duyệt/Hủy
protected void doPost(HttpServletRequest request, HttpServletResponse response) ... {
    
    // 1. Kết nối Database
    Connection conn = DBContext.getConnection();
    
    // 2. TẮT TỰ ĐỘNG LƯU (Quan trọng!)
    // Mặc định DB sẽ lưu ngay sau mỗi lệnh. Ta tắt đi để tự kiểm soát.
    conn.setAutoCommit(false); 

    try {
        // 3. Lấy thông tin từ nút bấm
        // 'action' là tên nút (approve, cancel, return)
        String action = request.getParameter("action"); 
        // 'id' là Mã đơn hàng cần xử lý
        int idDon = Integer.parseInt(request.getParameter("id"));
        
        // 4. Tìm Mã Xe liên quan đến Đơn đó
        // (Phải biết đơn này thuê xe nào thì mới cập nhật trạng thái xe được)
        int idXe = findCarIdByOrder(conn, idDon);

        // 5. Xử lý theo từng trường hợp
        if ("approve".equals(action)) { 
            // Nếu bấm DUYỆT:
            // - Đơn: Chuyển thành "Thành công" (đang thuê)
            updateOrderStatus(conn, idDon, "Thành công");
            // - Xe: Giữ nguyên là "Đang bận" (1)
            
        } else if ("return".equals(action)) {
            // Nếu bấm TRẢ XE (Hoàn tất):
            // - Đơn: Chuyển thành "Hoàn tất"
            updateOrderStatus(conn, idDon, "Hoàn tất");
            // - Xe: Chuyển thành "Rảnh" (0) để người khác thuê
            updateCarStatus(conn, idXe, 0);
            
        } else if ("cancel".equals(action)) {
            // Nếu bấm HỦY:
            updateOrderStatus(conn, idDon, "Đã hủy");
            // - Xe: Chuyển thành "Rảnh" (0) ngay lập tức
            updateCarStatus(conn, idXe, 0);
        }

        // 6. CAM KẾT (COMMIT)
        // Nếu chạy đến đây mà không lỗi -> Lưu tất cả thay đổi vào DB thật
        conn.commit();
        
    } catch (Exception e) {
        // 7. HOÀN TÁC (ROLLBACK)
        // Nếu có bất kỳ lỗi nào ở trên -> Hủy hết, coi như chưa làm gì
        conn.rollback();
    }
}
```
**Tại sao phải phức tạp vậy?**
Giả sử bạn bấm "Trả xe". Hệ thống đã cập nhật Đơn hàng xong, nhưng đến bước cập nhật Xe thì bị mất điện hoặc lỗi mạng.
*   Nếu không dùng Transaction: Đơn hàng báo đã trả, nhưng xe vẫn báo đang bận -> **Lỗi dữ liệu logic**.
*   Dùng Transaction: Vì bước 2 lỗi, nên bước 1 cũng bị hủy bỏ -> Mọi thứ quay về trạng thái cũ an toàn.

## 5. Database
*   **Bảng `nguoi_dung`**: Lưu tài khoản Admin (`vai_tro=1`).
*   **Bảng `xe_may`**: `trang_thai` (0: Rảnh, 1: Bận).
*   **Bảng `don_thue_xe`**: Lưu vết giao dịch.
