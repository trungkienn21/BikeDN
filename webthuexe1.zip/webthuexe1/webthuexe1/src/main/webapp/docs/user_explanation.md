# Tài Liệu Hướng Dẫn Kỹ Thuật & Chức Năng - User (Người Dùng)

## 1. Tổng Quan
Hệ thống cho phép người dùng (khách du lịch) xem danh sách xe, xem chi tiết và tự đặt xe trực tuyến mà không cần liên hệ thủ công.

## 2. Cấu Trúc Code & Logic
Luồng User tập trung tại thư mục `webapp/user/` và các Servlet chung (`BookingServlet`, `AuthServlet`).

### 2.1. Đăng Ký & Đăng Nhập
*   **File:** `auth/login.jsp`, `auth/register.jsp`
*   **Controller:** `AuthServlet.java`
*   **Logic:**
    *   Người dùng đăng ký -> Lưu vào DB với `vai_tro = 0` (Khách).
    *   Đăng nhập thành công -> Session lưu `userId` và `userFullName`.
    *   Nếu chưa đăng nhập, khách vẫn xem được xe nhưng khi bấm "Thuê ngay" sẽ bị chặn bằng JavaScript (`alertLogin()` trong `index.jsp`).

### 2.2. Trang Chủ (Danh Sách Xe)
*   **File:** `index.jsp`
*   **Chức năng:**
    *   Hiển thị dạng lưới (Grid) tất cả xe.
    *   Phân biệt trạng thái bằng màu sắc: **Xanh (Sẵn sàng)** vs **Đỏ (Hết xe)**.
    *   Logic hiển thị: Dùng Java Scriptlet (`<% ... %>`) để loop qua ResultSet từ bảng `xe_may`.

### 2.3. Xem Chi Tiết (Car Detail)
*   **File:** `user/detail.jsp` (trước đây là `chitietxe.jsp`)
*   **Chức năng:**
    *   Nhận tham số `id` từ URL.
    *   Query thông tin chi tiết xe.
    *   Hiển thị form chọn ngày thuê (`ngay_thue`, `ngay_tra`).
    *   **Validate:** JavaScript chặn không cho chọn ngày quá khứ hoặc ngày trả trước ngày thuê.

### 2.4. Xác Nhận & Đặt Xe (Booking)
*   **Bước 1 - Xác nhận:**
    *   **File:** `user/booking_confirm.jsp`
    *   Tính toán tạm tính tổng tiền: `(Ngày trả - Ngày thuê) * Giá ngày`.
    *   Hiển thị bill tạm để khách chốt.
*   **Bước 2 - Gửi đơn:**
    *   **Controller:** `BookingServlet.doPost`
    *   Logic:
        1.  Insert đơn vào `don_thue_xe` với trạng thái `Chờ duyệt`.
        2.  Update trạng thái xe trong `xe_may` thành `1` (Đang bận) ngay lập tức để tránh người khác đặt trùng.
        3.  Redirect người dùng về trang Lịch sử.

### 2.5. Lịch Sử & Hủy Đơn
*   **File:** `user/history.jsp`
*   **Controller:** `BookingServlet.doGet` (Xử lý hủy)
*   **Chức năng:**
    *   Xem danh sách các đơn đã đặt.
    *   **Hủy đơn:** Khách chỉ được hủy khi đơn đang ở trạng thái `Chờ duyệt`.
    *   Khi hủy: Hệ thống xóa đơn và hoàn lại trạng thái xe thành `Sẵn sàng`.

## 3. Giải Thích Code Chi Tiết cho User

### A. Lấy giá trị Form (Input)
Khi người dùng nhập Form Đăng ký hoặc Đặt xe:
```java
// Trong Servlet (AuthServlet hoặc BookingServlet)
String hoTen = request.getParameter("fullname"); // Lấy giá trị ô input name="fullname"
String ngayThue = request.getParameter("ngay_thue"); // Lấy ngày từ lịch
```

### B. Kiểm tra Đăng nhập (`index.jsp`)
Logic hiển thị nút "Thuê" hoặc "Đăng nhập":
```java
<% 
// Lấy userId từ session
if(session.getAttribute("userId") == null) { 
    // Chưa đăng nhập -> Biến clickAction sẽ gọi hàm JS alertLogin()
    clickAction = "alertLogin()"; 
} else {
    // Đã đăng nhập -> Cho phép bấm vào link chi tiết
    linkDetail = "user/detail.jsp?id=" + id;
}
%>
```

### C. Tính toán ngày giờ (Java Time)
Dùng gói `java.time` trong `booking_confirm.jsp` để tính số ngày thuê chính xác:
```java
LocalDate d1 = LocalDate.parse(ngayThue); // Chuyển chuỗi "2023-10-01" thành Date
LocalDate d2 = LocalDate.parse(ngayTra);
long soNgay = ChronoUnit.DAYS.between(d1, d2); // Tính khoảng cách ngày
double tongTien = soNgay * giaNgay; // Nhân tiền
```

### D. Truyền tham số qua URL (`GET`)
Khi bấm vào xem chi tiết một xe:
*   Link trên HTML: `<a href="user/detail.jsp?id=5">Xem xe</a>`
*   Code Java nhận (`detail.jsp`):
    ```java
    String idXe = request.getParameter("id"); // Nhận được số 5
    // Sau đó dùng số 5 này để Query DB lấy thông tin xe đó
    ```

## 4. Phân Tích Code: Luồng Đặt Xe (Booking Flow)
Dưới đây là chi tiết hàm `doPost` trong `BookingServlet` (Xử lý khi bấm nút "Gửi đơn"):

```java
protected void doPost(request, response) {
    // 1. Lấy User từ Session
    // (Bảo mật: Phải biết ai đang đặt. Nếu không có session -> Đuổi ra ngoài)
    HttpSession session = request.getSession();
    Integer userId = (Integer) session.getAttribute("userId");
    
    // 2. Nhận dữ liệu từ Form
    String idXe = request.getParameter("id_xe");  // Xe nào?
    String nThue = request.getParameter("ngay_thue"); // Mấy giờ lấy?
    String nTra = request.getParameter("ngay_tra");   // Mấy giờ trả?
    String tongTien = request.getParameter("tong_tien"); // Tiền bao nhiêu?

    // 3. Kết nối Database
    Connection conn = DBContext.getConnection();

    // 4. Lấy 'Mã Xe' (License Plate) từ ID Xe
    // (Vì form chỉ gửi ID số, ta cần lấy Biển Số để lưu vào đơn cho rõ ràng)
    String sqlGetMa = "SELECT ma_xe FROM xe_may WHERE id = ?";
    PreparedStatement ps1 = conn.prepareStatement(sqlGetMa);
    ps1.setInt(1, Integer.parseInt(idXe));
    ResultSet rs = ps1.executeQuery();
    
    if (rs.next()) {
        String maXe = rs.getString("ma_xe");

        // 5. TẠO ĐƠN HÀNG MỚI (INSERT)
        String sqlInsert = "INSERT INTO don_thue_xe (id_nguoi_dung, id_xe, ma_xe, ngay_thue, ngay_tra, tong_tien, trang_thai_don) VALUES (?, ?, ?, ?, ?, ?, 'Chờ duyệt')";
        PreparedStatement ps2 = conn.prepareStatement(sqlInsert);
        // ... (điền các dấu ? bằng dữ liệu ở trên) ...
        ps2.executeUpdate(); // Chạy lệnh INSERT

        // 6. KHÓA XE LẠI (UPDATE)
        // Set trạng thái = 1 (Bận) để người khác không đặt được xe này nữa
        String sqlLockCar = "UPDATE xe_may SET trang_thai = 1 WHERE id = ?";
        PreparedStatement ps3 = conn.prepareStatement(sqlLockCar);
        ps3.setInt(1, Integer.parseInt(idXe));
        ps3.executeUpdate(); // Chạy lệnh UPDATE

        // 7. THÀNH CÔNG -> Chuyển hướng
        response.sendRedirect("user/history.jsp");
    }
}
```

## 5. Các Thành Phần Xử Lý Phụ
*   **`config/db.jsp`:** File cấu hình kết nối Database trung tâm.
*   **`includes/client_navbar.jsp`**: Menu điều hướng, tự động đổi trạng thái (Đăng nhập/Đăng xuất) dựa theo Session.
*   **`includes/tinh_tien_ajax.jsp`**: API tính toán tiền thuê trước (nếu phát triển thêm tính năng tính Real-time).
