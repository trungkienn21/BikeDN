# Giải Thích Về doGet và doPost Trong Project Này

Bạn có thắc mắc: **"Trong bài có `doGet` và `doPost` không?"**

Câu trả lời là: **KHÔNG**.
Project này **không** có các hàm `doGet` hay `doPost` cụ thể nào cả.

## Tại sao lại như vậy?

Project của bạn được viết hoàn toàn bằng **JSP (JavaServer Pages)**, không sử dụng class **Servlet** Java thuần túy.

### 1. Nếu dùng Servlet (Java Class)
Bạn sẽ phải viết code như thế này:
```java
public class LoginServlet extends HttpServlet {
    // Hàm này chạy khi user gõ URL hoặc bấm link (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        // ... code ...
    }

    // Hàm này chạy khi user bấm nút Submit Form (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        // ... code ...
    }
}
```

### 2. Nhưng khi dùng JSP (Project này)
JSP thực chất là một phiên bản rút gọn. Khi chạy, máy chủ Tomcat sẽ tự động biến file `.jsp` thành một Servlet.
Toàn bộ code bạn viết trong thẻ `<% ... %>` sẽ được đặt vào một hàm chung tên là **`_jspService()`**.

Hàm `_jspService()` này xử lý **TẤT CẢ** các loại request, bất kể là GET hay POST.

### Cách Project này xử lý GET và POST

Thay vì tách hai hàm riêng, ta phân biệt bằng logic code (nếu cần):

Ví dụ trong `xuly_xe.jsp`:
*   Code này **nhận cả GET và POST**.
*   Khi bạn bấm nút xóa (`<a href="...">`): Đây là **GET**.
*   Khi bạn bấm nút lưu form (`<form method="post">`): Đây là **POST**.

Dù là GET hay POST, lệnh `request.getParameter("action")` đều lấy được dữ liệu.

## Tóm lại
*   **Project này không có `doGet`/`doPost` vì nó dùng JSP, không dùng Servlet class.**
*   Mọi logic chạy chung trong một luồng từ trên xuống dưới.
*   Cách viết này (Model 1) đơn giản, dễ học cho người mới, nhưng với các hệ thống lớn người ta thường dùng Servlet (Model 2) để tách bạch `doGet`/`doPost` rõ ràng hơn.
