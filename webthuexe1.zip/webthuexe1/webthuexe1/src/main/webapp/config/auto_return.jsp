<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <%@ page import="java.sql.*" %>
        <% try { Connection connAuto=com.webthuexe.db.DBContext.getConnection(); String
            sqlAuto="UPDATE xe_may JOIN don_thue_xe ON xe_may.id = don_thue_xe.id_xe "
            + "SET xe_may.trang_thai = 0, don_thue_xe.trang_thai_don = 'Hoàn tất' "
            + "WHERE don_thue_xe.ngay_tra < CURRENT_DATE() "
            + "AND xe_may.trang_thai = 1 AND don_thue_xe.trang_thai_don NOT IN ('Hoàn tất', 'Đã hủy')" ; Statement
            stAuto=connAuto.createStatement(); stAuto.executeUpdate(sqlAuto); connAuto.close(); } catch (Exception e) {
            /* Ignore benign errors */ } %>