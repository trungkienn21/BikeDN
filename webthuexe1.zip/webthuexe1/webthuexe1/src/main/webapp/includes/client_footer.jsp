<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <footer class="footer text-center mt-5">
        <div class="container">
            <p class="fw-bold text-success mb-1">DỊCH VỤ THUÊ XE MÁY ĐÀ NẴNG</p>
            <p class="small text-muted mb-0">Địa chỉ: 144 Đoàn Phú Tứ, Đà Nẵng | Hotline: 038 798 5760</p>
            <p class="small text-muted mt-2">&copy; 2025 - All Rights Reserved</p>
            <p class="small text-muted mb-0">Design by: Kiên đẹp trai và Sáng gió tai</p>
        </div>
    </footer>