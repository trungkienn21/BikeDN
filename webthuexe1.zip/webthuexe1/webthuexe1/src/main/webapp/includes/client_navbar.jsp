<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<nav class="navbar navbar-expand-lg sticky-top mb-4 bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="${pageContext.request.contextPath}/XeMay">
            <i class="bi bi-tags-fill fs-2 text-success me-2"></i>
            <span class="fw-bold fs-4 text-dark">THUEXEDANANG</span>
        </a>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link fw-bold" href="${pageContext.request.contextPath}/XeMay">Trang Chủ</a></li>
                <li class="nav-item"><a class="nav-link fw-bold" href="${pageContext.request.contextPath}/user/history.jsp">Lịch Sử Thuê</a></li>
            </ul>

            <div class="d-flex align-items-center">
                <%-- Kiểm tra biến 'userId' trong Session --%>
                <c:choose>
                    <c:when test="${not empty sessionScope.userId}">
                        <div class="d-flex align-items-center">
                            <span class="text-success fw-bold me-3">
                                <i class="bi bi-person-circle"></i> Xin chào, ${sessionScope.userFullName}
                            </span>

                            <c:if test="${sessionScope.isAdmin == true}">
                                <a href="${pageContext.request.contextPath}/admin/dashboard.jsp" class="btn btn-danger btn-sm me-2 fw-bold">
                                    <i class="bi bi-shield-lock-fill"></i> Quản trị
                                </a>
                            </c:if>

                            <a class="btn btn-outline-dark btn-sm fw-bold" href="${pageContext.request.contextPath}/auth?action=logout">
                                <i class="bi bi-box-arrow-right"></i> Đăng xuất
                            </a>
                        </div>
                    </c:when>
                    <c:otherwise>
                        <a href="${pageContext.request.contextPath}/auth/login.jsp" class="btn btn-outline-success me-2 fw-bold">Đăng Nhập</a>
                        <a href="${pageContext.request.contextPath}/auth/register.jsp" class="btn btn-success fw-bold px-3">Đăng Ký</a>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </div>
</nav>