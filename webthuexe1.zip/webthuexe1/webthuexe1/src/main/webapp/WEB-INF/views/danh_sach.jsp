<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thuê Xe Máy Đà Nẵng - Danh Sách Xe</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <style>
        body { background-color: #f8f9fa; }
        .bike-card { transition: 0.3s; border-radius: 20px; overflow: hidden; border: none; }
        .bike-card:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.1) !important; }
        .bike-img-container { height: 200px; display: flex; align-items: center; justify-content: center; background: #fff; }
        .bike-img { max-width: 90%; max-height: 90%; object-fit: contain; }
        .badge-status { position: absolute; top: 15px; right: 15px; padding: 8px 15px; border-radius: 12px; font-weight: 600; }
        .price-text { color: #198754; font-weight: 800; font-size: 1.3rem; }
        .btn-rent { border-radius: 12px; font-weight: 700; padding: 10px; transition: 0.2s; }
    </style>
</head>

<body>
    <jsp:include page="/includes/client_navbar.jsp" />

    <div class="container py-5">
        <div class="text-center mb-5">
            <h2 class="fw-bold text-uppercase display-6">Hệ Thống Xe Sẵn Sàng</h2>
            <div class="mx-auto bg-success mb-3" style="height: 4px; width: 80px; border-radius: 2px;"></div>
            <p class="text-muted">Lựa chọn người bạn đồng hành tin cậy trên mọi cung đường Đà Nẵng</p>
        </div>

        <div class="row g-4">
            <c:choose>
                <c:when test="${not empty listXe}">
                    <c:forEach items="${listXe}" var="xe">
                        <div class="col-12 col-sm-6 col-lg-3">
                            <div class="card bike-card h-100 shadow-sm position-relative">
                                
                                
                                <c:choose>
                                    <c:when test="${xe.trangThai == 1}">
                                        <span class="badge bg-danger badge-status"><i class="bi bi-lock-fill"></i> ĐÃ THUÊ</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="badge bg-success badge-status"><i class="bi bi-check-circle-fill"></i> SẴN SÀNG</span>
                                    </c:otherwise>
                                </c:choose>


                                <div class="bike-img-container">
                                    <img src="images/${not empty xe.hinhAnh ? xe.hinhAnh : 'default.png'}" 
                                         class="bike-img" alt="${xe.tenXe}">
                                </div>
                                

                                <div class="card-body text-center d-flex flex-column">
                                    <div class="mb-2">
                                        <span class="badge bg-light text-dark border">${xe.loaiXe}</span>
                                    </div>
                                    <h5 class="fw-bold text-dark mb-3">${xe.tenXe}</h5>
                                    
                                    
                                    <div class="mt-auto">
                                        <p class="price-text mb-3">
                                            <fmt:formatNumber value="${xe.giaThue}" pattern="#,###" /> VNĐ
                                            <small class="text-muted fs-6 fw-normal">/ ngày</small>
                                        </p>


                                        <c:choose>
                                            <c:when test="${xe.trangThai == 1}">
                                                <button class="btn btn-outline-secondary w-100 btn-rent" disabled>ĐANG BẬN</button>
                                            </c:when>
                                            <c:otherwise>
                                                <c:choose>
    <c:when test="${not empty sessionScope.userId}">
    <%-- Đổi từ link trực tiếp JSP sang Servlet --%>
    <a href="${pageContext.request.contextPath}/xe-chi-tiet?id=${xe.id}" class="btn btn-success w-100 btn-rent">
        <i class="bi bi-cart-plus-fill me-1"></i> THUÊ NGAY
    </a>
</c:when>
    <c:otherwise>
        <%-- Nếu chưa đăng nhập --%>
        <button onclick="alertLogin()" class="btn btn-success w-100 btn-rent">
            <i class="bi bi-cart-plus-fill me-1"></i> THUÊ NGAY
        </button>
    </c:otherwise>
</c:choose>
                                            </c:otherwise>
                                        </c:choose>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </c:when>
                <c:otherwise>
                    <div class="col-12 text-center py-5">
                        <i class="bi bi-bicycle display-1 text-muted opacity-25"></i>
                        <p class="mt-3 fs-5 text-muted">Rất tiếc, hiện tại danh sách xe đang trống!</p>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <jsp:include page="/includes/client_footer.jsp" />

    <script>
        function alertLogin() {
            Swal.fire({
                title: 'Thông báo',
                text: "Bạn cần đăng nhập để thực hiện đặt xe!",
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#198754',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Đến trang đăng nhập',
                cancelButtonText: 'Đóng'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'auth/login.jsp';
                }
            })
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>