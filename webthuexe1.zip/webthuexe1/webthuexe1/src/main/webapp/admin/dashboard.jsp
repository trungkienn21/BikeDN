<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <%@ page import="java.sql.*" %>
        <%@ page import="com.webthuexe.db.DBContext" %>
            <% /* Check Session Login */ if(session.getAttribute("isAdmin")==null) {
                response.sendRedirect("../auth/login.jsp"); return; } %>
                <%@ include file="../config/auto_return.jsp" %>
                    <!DOCTYPE html>
                    <html lang="vi">

                    <head>
                        <meta charset="UTF-8">
                        <title>Dashboard - Quản Trị Hệ Thống</title>
                        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
                            rel="stylesheet">
                        <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
                        <link rel="stylesheet" href="../assets/css/admin.css">
                    </head>

                    <body>
                        <jsp:include page="includes/navbar.jsp" />

                        <div class="container">
                            <h2 class="mb-4">Tổng Quan Hệ Thống</h2>

                            <% int totalBikes=0; int rentedBikes=0; int totalOrders=0; double revenue=0; try {
                                Connection conn=DBContext.getConnection(); /* Thong ke xe */ Statement
                                st1=conn.createStatement(); String
                                sql1="SELECT COUNT(*) as total, SUM(CASE WHEN trang_thai=1 THEN 1 ELSE 0 END) as rented FROM xe_may"
                                ; ResultSet rs1=st1.executeQuery(sql1); if(rs1.next()) { totalBikes=rs1.getInt("total");
                                rentedBikes=rs1.getInt("rented"); } /* Thong ke don hang va Doanh thu (Chi tinh don OK)
                                */ Statement st2=conn.createStatement(); String
                                sql2="SELECT COUNT(*) as cnt, SUM(CASE WHEN trang_thai_don = 'Hoàn tất' THEN tong_tien ELSE 0 END) as total_rev FROM don_thue_xe WHERE trang_thai_don != 'Đã hủy'"
                                ; ResultSet rs2=st2.executeQuery(sql2); if(rs2.next()) { totalOrders=rs2.getInt("cnt");
                                revenue=rs2.getDouble("total_rev"); } conn.close(); } catch(Exception e) {
                                e.printStackTrace(); } %>

                                <div class="row g-4">
                                    <div class="col-md-3">
                                        <div class="card bg-primary text-white h-100">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="card-title">TỔNG SỐ XE</h6>
                                                        <h2 class="mb-0">
                                                            <%= totalBikes %>
                                                        </h2>
                                                    </div>
                                                    <i class="bi bi-bicycle fs-1 opacity-50"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="card bg-warning text-dark h-100">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="card-title">ĐANG CHO THUÊ</h6>
                                                        <h2 class="mb-0">
                                                            <%= rentedBikes %>
                                                        </h2>
                                                    </div>
                                                    <i class="bi bi-key fs-1 opacity-50"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="card bg-success text-white h-100">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="card-title">ĐƠN THÀNH CÔNG</h6>
                                                        <h2 class="mb-0">
                                                            <%= totalOrders %>
                                                        </h2>
                                                    </div>
                                                    <i class="bi bi-file-earmark-text fs-1 opacity-50"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="card bg-danger text-white h-100">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="card-title">DOANH THU THỰC</h6>
                                                        <h3 class="mb-0">
                                                            <%= java.text.NumberFormat.getIntegerInstance().format(revenue)
                                                                %> đ
                                                        </h3>
                                                    </div>
                                                    <i class="bi bi-cash-coin fs-1 opacity-50"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-5 text-center">
                                    <img src="https://cdni.iconscout.com/illustration/premium/thumb/admin-panel-4439223-3728450.png"
                                        alt="Admin Illustration" class="admin-illustration">
                                    <p class="text-muted mt-3">Hệ thống đang tự động cập nhật trạng thái xe thuê quá
                                        hạn.</p>
                                </div>
                        </div>

                        <script
                            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
                    </body>

                    </html>