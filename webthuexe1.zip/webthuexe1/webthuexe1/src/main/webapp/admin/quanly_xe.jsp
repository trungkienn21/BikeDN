<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <%@ page import="java.sql.*" %>
        <%@ page import="com.webthuexe.db.DBContext" %>
            <% /* Authenticate Admin */ if(session.getAttribute("isAdmin")==null) {
                response.sendRedirect("../auth/login.jsp"); return; } %>
                <%@ include file="../config/auto_return.jsp" %>
                    <!DOCTYPE html>
                    <html lang="vi">

                    <head>
                        <meta charset="UTF-8">
                        <title>Quản Lý Xe - Admin</title>
                        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
                            rel="stylesheet">
                        <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
                        <link rel="stylesheet" href="../assets/css/admin.css">
                        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                    </head>

                    <body>

                        <jsp:include page="includes/navbar.jsp" />

                        <div class="container">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <h2>Danh Sách Xe Máy</h2>
                                <a href="form_xe.jsp" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Thêm Xe
                                    Mới</a>
                            </div>

                            <% String msg=request.getParameter("msg"); if("success".equals(msg)) { %>
                                <div class="alert alert-success">Thao tác thành công!</div>
                                <% } else if("error".equals(msg)) { %>
                                    <div class="alert alert-danger">Đã có lỗi xảy ra!</div>
                                    <% } %>

                                        <div class="card shadow-sm">
                                            <div class="card-body">
                                                <table class="table table-hover align-middle">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>Hình Ảnh</th>
                                                            <th>Mã Xe</th>
                                                            <th>Tên Xe</th>
                                                            <th>Loại Xe</th>
                                                            <th>Giá Thuê/Ngày</th>
                                                            <th>Trạng Thái</th>
                                                            <th>Hành Động</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <% try { Connection conn=DBContext.getConnection(); Statement
                                                            st=conn.createStatement(); String
                                                            sql="SELECT * FROM xe_may ORDER BY id DESC" ; ResultSet
                                                            rs=st.executeQuery(sql); while(rs.next()) { int
                                                            id=rs.getInt("id"); String hinh=rs.getString("hinh_anh");
                                                            double gt=rs.getDouble("gia_thue"); String
                                                            gia=java.text.NumberFormat.getIntegerInstance().format(gt);
                                                            String loaiXe=rs.getString("loai_xe"); if(loaiXe==null)
                                                            loaiXe="-" ; %>
                                                            <tr>
                                                                <td>#<%=id%>
                                                                </td>
                                                                <td>
                                                                    <img src="../images/<%=hinh%>" alt="anh"
                                                                        class="table-img">
                                                                </td>
                                                                <td>
                                                                    <%=rs.getString("ma_xe")%>
                                                                </td>
                                                                <td class="fw-bold">
                                                                    <%=rs.getString("ten_xe")%>
                                                                </td>
                                                                <td>
                                                                    <%=loaiXe%>
                                                                </td>
                                                                <td class="text-success fw-bold">
                                                                    <%=gia%> đ
                                                                </td>
                                                                <td>
                                                                    <% if(rs.getInt("trang_thai")==0) { %>
                                                                        <span class="badge bg-success">Sẵn sàng</span>
                                                                        <% } else { %>
                                                                            <span class="badge bg-danger">Đang
                                                                                thuê</span>
                                                                            <% } %>
                                                                </td>
                                                                <td>
                                                                    <a href='form_xe.jsp?id=<%=id%>'
                                                                        class="btn btn-sm btn-warning me-1">
                                                                        <i class="bi bi-pencil-square"></i>
                                                                    </a>
                                                                    <button onclick='confirmDelete(<%=id%>)'
                                                                        class="btn btn-sm btn-danger">
                                                                        <i class="bi bi-trash"></i>
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                            <% } conn.close(); } catch(Exception e) { %>
                                                                <tr>
                                                                    <td colspan='8'>Lỗi: <%= e.getMessage() %>
                                                                    </td>
                                                                </tr>
                                                                <% } %>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                        </div>

                        <script>
                            function confirmDelete(id) {
                                Swal.fire({
                                    title: 'Bạn chắc chắn chứ?',
                                    text: "Hành động này sẽ xóa xe vĩnh viễn!",
                                    icon: 'warning',
                                    showCancelButton: true,
                                    confirmButtonColor: '#d33',
                                    cancelButtonColor: '#3085d6',
                                    confirmButtonText: 'Xóa ngay',
                                    cancelButtonText: 'Hủy'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href = 'car-manager?action=delete&id=' + id;
                                    }
                                })
                            }
                        </script>
                        <script
                            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
                    </body>

                    </html>