<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <%@ page import="java.sql.*" %>
        <%@ page import="com.webthuexe.db.DBContext" %>
            <% /* Authenticate Admin */ if(session.getAttribute("isAdmin")==null) {
                response.sendRedirect("../auth/login.jsp"); return; } %>
                <!DOCTYPE html>
                <html lang="vi">

                <head>
                    <meta charset="UTF-8">
                    <title>Quản Lý Đơn Hàng - Admin</title>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
                        rel="stylesheet">
                    <link rel="stylesheet"
                        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
                    <link rel="stylesheet" href="../assets/css/admin.css">
                    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                </head>

                <body>

                    <jsp:include page="includes/navbar.jsp" />

                    <div class="container">
                        <h2 class="mb-4">Danh Sách Đơn Thuê Xe</h2>

                        <div class="card shadow-sm">
                            <div class="card-body">
                                <table class="table table-hover align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Mã Đơn</th>
                                            <th>Khách Hàng</th>
                                            <th>Xe Thuê</th>
                                            <th>Ngày Thuê</th>
                                            <th>Ngày Trả</th>
                                            <th>Tổng Tiền</th>
                                            <th>Trạng Thái</th>
                                            <th>Hành Động</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <% try { Connection conn=DBContext.getConnection(); Statement
                                            st=conn.createStatement(); /* Join 3 tables: don_thue_xe, nguoi_dung, xe_may
                                            */ String
                                            sql="SELECT d.id, u.ho_ten, x.ten_xe, d.ngay_thue, d.ngay_tra, d.tong_tien, d.trang_thai_don, d.id_xe "
                                            + "FROM don_thue_xe d " + "JOIN nguoi_dung u ON d.id_nguoi_dung = u.id "
                                            + "JOIN xe_may x ON d.id_xe = x.id " + "ORDER BY d.id DESC" ; ResultSet
                                            rs=st.executeQuery(sql); while(rs.next()) { int id=rs.getInt("id"); int
                                            idXe=rs.getInt("id_xe"); String khach=rs.getString("ho_ten"); String
                                            xe=rs.getString("ten_xe"); Date ngayThue=rs.getDate("ngay_thue"); Date
                                            ngayTra=rs.getDate("ngay_tra"); double tien=rs.getDouble("tong_tien");
                                            String tt=rs.getString("trang_thai_don"); String colorBadge="bg-secondary" ;
                                            if(tt.equals("Chờ duyệt")) { colorBadge="bg-warning text-dark" ; } else
                                            if(tt.equals("Đang thuê") || tt.equals("Thành công")) {
                                            colorBadge="bg-primary" ; } else if(tt.equals("Hoàn tất")) {
                                            colorBadge="bg-success" ; } else if(tt.equals("Đã hủy")) {
                                            colorBadge="bg-danger" ; } %>
                                            <tr>
                                                <td>#<%=id%>
                                                </td>
                                                <td>
                                                    <%=khach%>
                                                </td>
                                                <td class="fw-bold">
                                                    <%=xe%>
                                                </td>
                                                <td>
                                                    <%=ngayThue%>
                                                </td>
                                                <td>
                                                    <%=ngayTra%>
                                                </td>
                                                <td class="fw-bold text-success">
                                                    <%=java.text.NumberFormat.getIntegerInstance().format(tien)%> đ
                                                </td>
                                                <td>
                                                    <span class="badge <%=colorBadge%>">
                                                        <%=tt%>
                                                    </span>
                                                </td>
                                                <td>
                                                    <% if(tt.equals("Chờ duyệt")) { %>
                                                        <a href="order-manager?id=<%=id%>&action=approve&id_xe=<%=idXe%>"
                                                            class="btn btn-sm btn-success">
                                                            <i class="bi bi-check-lg"></i> Duyệt
                                                        </a>
                                                        <a href="order-manager?id=<%=id%>&action=cancel&id_xe=<%=idXe%>"
                                                            class="btn btn-sm btn-danger">
                                                            <i class="bi bi-x-lg"></i> Hủy
                                                        </a>
                                                        <% } else if(tt.equals("Đang thuê") || tt.equals("Thành công"))
                                                            { %>
                                                            <a href="order-manager?id=<%=id%>&action=complete&id_xe=<%=idXe%>"
                                                                class="btn btn-sm btn-primary">
                                                                <i class="bi bi-check2-circle"></i> Hoàn tất
                                                            </a>
                                                            <% } else { %>
                                                                <span class="text-muted small"><i
                                                                        class="bi bi-lock"></i> Đã đóng</span>
                                                                <% } %>
                                                </td>
                                            </tr>
                                            <% } conn.close(); } catch(Exception e) { %>
                                                <tr>
                                                    <td colspan='8'>Lỗi: <%= e.getMessage() %>
                                                    </td>
                                                </tr>
                                                <% } %>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
                </body>

                </html>