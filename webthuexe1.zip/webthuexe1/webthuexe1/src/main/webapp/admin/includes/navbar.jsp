<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold text-success" href="<%= request.getContextPath() %>/admin/dashboard.jsp">
                Quản Trị Viên
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="adminNav">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<%= request.getContextPath() %>/admin/dashboard.jsp">Tổng Quan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<%= request.getContextPath() %>/admin/quanly_xe.jsp">Quản Lý Xe</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<%= request.getContextPath() %>/admin/quanly_don.jsp">Đơn Hàng</a>
                    </li>
                </ul>
                <div class="d-flex border-start ms-3 ps-3">
                    <a class="nav-link text-danger fw-bold me-3" href="<%= request.getContextPath() %>/index.jsp">
                        <i class="bi bi-arrow-left-circle"></i> Quay lại website
                    </a>
                    <a class="nav-link text-secondary" href="<%= request.getContextPath() %>/auth?action=logout">
                        <i class="bi bi-box-arrow-right"></i> Đăng xuất
                    </a>
                </div>
            </div>
        </div>
    </nav>