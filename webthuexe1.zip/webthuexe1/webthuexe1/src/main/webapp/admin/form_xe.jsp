<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <%@ page import="java.sql.*" %>
        <% if(session.getAttribute("isAdmin")==null) { response.sendRedirect("../auth/login.jsp"); return; } %>
            <!DOCTYPE html>
            <html lang="vi">

            <head>
                <meta charset="UTF-8">
                <title>Form Xe - Admin</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                <link rel="stylesheet" href="../assets/css/admin.css">
            </head>

            <body>

                <jsp:include page="includes/navbar.jsp" />

                <div class="container">
                    <% String idParam=request.getParameter("id"); String maXe="" , tenXe="" , loaiXe="" , hinh="" ;
                        double giaThue=0; int trangThai=0; String actionTitle="Thêm Xe Mới" ; if(idParam !=null &&
                        !idParam.isEmpty()) { actionTitle="Cập Nhật Thông Tin Xe" ; try {
                        Class.forName("com.mysql.cj.jdbc.Driver"); String url="jdbc:mysql://localhost:3306/webthuexe" ;
                        Connection conn=DriverManager.getConnection(url, "root" , "" ); String
                        sql="SELECT * FROM xe_may WHERE id=?" ; PreparedStatement pst=conn.prepareStatement(sql);
                        pst.setString(1, idParam); ResultSet rs=pst.executeQuery(); if(rs.next()) {
                        maXe=rs.getString("ma_xe"); tenXe=rs.getString("ten_xe"); loaiXe=rs.getString("loai_xe");
                        giaThue=rs.getDouble("gia_thue"); hinh=rs.getString("hinh_anh");
                        trangThai=rs.getInt("trang_thai"); } conn.close(); } catch(Exception e) { } } %>

                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-primary text-white">
                                        <h4 class="mb-0">
                                            <%= actionTitle %>
                                        </h4>
                                    </div>
                                    <div class="card-body">
                                        <form action="car-manager" method="post" id="xeForm">
                                            <input type="hidden" name="id" value="<%= (idParam!=null)?idParam:"" %>">

                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Mã Xe</label>
                                                    <input type="text" name="ma_xe" class="form-control"
                                                        value="<%= maXe %>" required>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Loại Xe</label>
                                                    <input type="text" name="loai_xe" class="form-control"
                                                        value="<%= loaiXe %>" required>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Tên Xe</label>
                                                <input type="text" name="ten_xe" class="form-control"
                                                    value="<%= tenXe %>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Giá Thuê (VNĐ/Ngày)</label>
                                                <input type="number" name="gia_thue" class="form-control"
                                                    value="<%= (long)giaThue %>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Hình Ảnh</label>

                                                <!-- Hidden inputs for logic -->
                                                <input type="hidden" name="hinh_anh" id="hinh_anh" value="<%= hinh %>">
                                                <input type="hidden" name="base64_img" id="base64_img">

                                                <!-- Visible File Input -->
                                                <input type="file" id="fileInput" class="form-control" accept="image/*">

                                                <!-- Preview -->
                                                <div class="mt-2 text-center border rounded p-2 img-preview-container">
                                                    <% String imgSrc=(hinh!=null && !hinh.isEmpty()) ? "../images/" +
                                                        hinh : "https://via.placeholder.com/150" ; %>
                                                        <img id="imgPreview" src="<%= imgSrc %>" class="img-preview">
                                                        <div id="fileNameDisplay" class="text-muted small mt-1">
                                                            <%= (hinh!=null)?hinh:"Chưa chọn ảnh" %>
                                                        </div>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Trạng Thái</label>
                                                <select name="trang_thai" class="form-select">
                                                    <option value="0" <%=(trangThai==0)?"selected":"" %>>Sẵn sàng
                                                    </option>
                                                    <option value="1" <%=(trangThai==1)?"selected":"" %>>Đang thuê
                                                    </option>
                                                </select>
                                            </div>

                                            <div class="d-flex justify-content-between">
                                                <a href="quanly_xe.jsp" class="btn btn-secondary">Quay Lại</a>
                                                <button type="submit" class="btn btn-success">Lưu Thông Tin</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>

                <script>
                    document.getElementById('fileInput').addEventListener('change', function (e) {
                        var file = e.target.files[0];
                        if (file) {
                            // 1. Alert size check (limit 2MB for safety)
                            if (file.size > 2 * 1024 * 1024) {
                                alert('File quá lớn! Vui lòng chọn ảnh < 2MB');
                                this.value = '';
                                return;
                            }

                            // 2. Update Filename Hidden Input
                            document.getElementById('hinh_anh').value = file.name;
                            document.getElementById('fileNameDisplay').innerText = file.name;

                            // 3. Convert to Base64
                            var reader = new FileReader();
                            reader.onload = function (readerEvt) {
                                var binaryString = readerEvt.target.result;
                                // Remove data:image... prefix
                                document.getElementById('base64_img').value = binaryString.split(',')[1];
                                // Show preview
                                document.getElementById('imgPreview').src = binaryString;
                            };
                            reader.readAsDataURL(file);
                        }
                    });
                </script>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
            </body>

            </html>