<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <!DOCTYPE html>
    <html lang="vi">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Đăng Nhập - WebThueXe</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../assets/css/auth.css">
    </head>

    <body>

        <div class="auth-card shadow">
            <div class="text-center mb-4">
                <h3 class="fw-bold text-success">ĐĂNG NHẬP</h3>
                <p class="text-muted small">Vui lòng nhập tài khoản để thuê xe</p>
            </div>

            <%-- Hiển thị thông báo lỗi nếu có --%>
                <% if(request.getAttribute("error") !=null) { %>
                    <div class="alert alert-danger p-2 small text-center">
                        <%= request.getAttribute("error") %>
                    </div>
                    <% } %>

                        <%-- Action và Method cực kỳ quan trọng --%>
                            <form action="../auth?action=login" method="post">

                                <% String msg=request.getParameter("msg"); if("error".equals(msg)) { %>
                                    <div class="alert alert-danger" role="alert">
                                        <i class="bi bi-exclamation-circle-fill"></i> Tên đăng nhập hoặc mật khẩu không
                                        đúng!
                                    </div>
                                    <% } else if("register_success".equals(msg)) { %>
                                        <div class="alert alert-success" role="alert">
                                            <i class="bi bi-check-circle-fill"></i> Đăng ký thành công! Vui lòng đăng
                                            nhập.
                                        </div>
                                        <% } %>
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Tên đăng nhập</label>
                                                    <input type="text" name="ten_dang_nhap" class="form-control"
                                                        placeholder="Nhập tên tài khoản" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Mật khẩu</label>
                                                
                                                    <input type="password" name="matkhau" class="form-control"
                                                        placeholder="Nhập mật khẩu" required>
                                            </div>

                                            <div class="mb-3 d-flex justify-content-between">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="remember">
                                                    <label class="form-check-label small" for="remember">Ghi nhớ</label>
                                                </div>
                                                <a href="#" class="small text-decoration-none text-muted">Quên mật
                                                    khẩu?</a>
                                            </div>

                                            <button type="submit" class="btn btn-auth w-100 py-2">Đăng Nhập</button>

                                            <div class="text-center mt-4 small">
                                                Chưa có tài khoản? <a href="register.jsp"
                                                    class="text-success fw-bold text-decoration-none">Đăng ký ngay</a>
                                            </div>
                            </form>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>

    </html>