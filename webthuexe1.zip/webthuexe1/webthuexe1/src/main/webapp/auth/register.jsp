<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Đăng Ký - Thuê Xe Đà Nẵng</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../assets/css/auth.css">
    </head>

    <body>
        <div class="auth-card shadow">
            <h3 class="text-center fw-bold mb-4 text-success">ĐĂNG KÝ</h3>
            <form action="../auth?action=register" method="post" onsubmit="return validateForm()">

                <% String msg=request.getParameter("msg"); if("invalid_code".equals(msg)) { %>
                    <div class="alert alert-danger">Mã an toàn không đúng!</div>
                    <% } else if("exists".equals(msg)) { %>
                        <div class="alert alert-danger">Tên đăng nhập đã tồn tại!</div>
                        <% } %>
                            <div class="mb-3">
                                <label class="form-label">Tên đăng nhập</label>
                                <input type="text" name="user" class="form-control" required
                                    placeholder="Nhập tên tài khoản">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Mật khẩu</label>
                                <input type="password" name="pass" class="form-control" required placeholder="********">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Họ tên</label>
                                <input type="text" name="fullname" class="form-control" placeholder="Nguyễn Văn A">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required
                                    placeholder="Nhập email của bạn">
                            </div>
                            <button type="submit" class="btn btn-auth w-100 py-2">Tạo Tài Khoản</button>
                            <p class="text-center mt-3 small">Đã có tài khoản? <a href="login.jsp"
                                    class="text-success">Đăng nhập ngay</a></p>
            </form>
        </div>
    </body>

    </html>